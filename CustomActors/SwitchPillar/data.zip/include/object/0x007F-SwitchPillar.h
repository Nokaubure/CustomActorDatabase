#ifndef __REDBLUEBLOCK_H__
#define __REDBLUEBLOCK_H__

extern u16 gRedblueblock_TexNormalpillar[];
extern u16 gRedblueblock_TexToppillar[];
extern u16 gRedblueblock_TexTriforcepillar[];
extern Gfx gRedblueblock_MtlNormalpillar[];
extern Gfx gRedblueblock_MtlToppillar[];
extern Gfx gRedblueblock_MtlTriforcepillar[];
extern CollisionHeader gRedblueblock_CollSinglepillar[];
extern CollisionHeader gRedblueblock_CollTriplepillar[];
extern Gfx gRedblueblock_DlSinglepillar[];
extern Gfx gRedblueblock_DlTriplepillar[];
extern Gfx gRedblueblock_DlDummytriforce[];

#endif /* __REDBLUEBLOCK_H__ */
