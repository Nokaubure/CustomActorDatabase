#ifndef __MOVINGPLATFORM_H__
#define __MOVINGPLATFORM_H__

extern u16 gMovingplatform_TexMovingPlatformTop00[];
extern u16 gMovingplatform_TexMovingPlatformSide00[];
extern u16 gMovingplatform_TexMovingPlatformBottom00[];
extern Gfx gMovingplatform_MtlMaterial[];
extern Gfx gMovingplatform_MtlMaterial001[];
extern Gfx gMovingplatform_MtlMaterial002[];
extern CollisionHeader gMovingplatform_CollPlatform[];
extern Gfx gMovingplatform_DlPlatform[];

#endif /* __MOVINGPLATFORM_H__ */
