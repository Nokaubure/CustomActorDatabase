#ifndef __ROOMTELEPORTER_H__
#define __ROOMTELEPORTER_H__

extern u16 gRoomTeleporter_TexRoomteleporter[];
extern u16 gRoomTeleporter_TexRoomteleporter2[];
extern Gfx gRoomTeleporter_MtlAnimated[];
extern Gfx gRoomTeleporter_MtlStatic[];
extern CollisionHeader gRoomTeleporter_CollRoomTeleporterCol[];
extern Gfx gRoomTeleporter_DlRoomTeleporter[];

#endif /* __ROOMTELEPORTER_H__ */
