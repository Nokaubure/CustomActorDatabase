#ifndef __SWITCHWATER_H__
#define __SWITCHWATER_H__

extern u16 gSwitchwater_TexRGBA1606000890[];
extern Gfx gSwitchwater_MtlMtl06000890[];
extern Gfx gSwitchwater_DlWaterplane[];

#endif /* __SWITCHWATER_H__ */
